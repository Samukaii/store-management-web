export interface AutocompleteOption {
	id: number | string;
	name: string;
}
