export interface NoResultsAction {
	message: string;
	icon?: string;
	action?: () => void;
}
