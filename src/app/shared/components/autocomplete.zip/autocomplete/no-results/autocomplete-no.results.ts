import { showGoToCreation } from "./show-go-to-creation";
import { autoCreation } from "./auto-creation";

export const AutocompleteNoResults = {
	showGoToCreation,
	autoCreation
}
